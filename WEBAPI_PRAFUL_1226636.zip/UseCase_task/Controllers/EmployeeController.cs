﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using UseCase_task.DTO;
using Microsoft.Extensions.Configuration;

namespace UseCase_task.Controllers
{
    [Route("api/Employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private IConfiguration Configuration;

        public EmployeeController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        [HttpPost("Retrieve_Employee")]
        public EmployeeRes Retrieve_Employee(Master _RequestData)
        {
            EmployeeReq EmpReq = new EmployeeReq();
            EmployeeRes EmpRes = new EmployeeRes();
            Common objcommon = new Common(Configuration);

            JObject obj = objcommon.Jobjdata(_RequestData.requestText);
            //JObject obj = (JObject)_RequestData.requestText;
            if (obj.Count != 0)
            {
                EmpReq.EmpID = Convert.ToInt32(obj["EmpID"]);
                EmpReq.Fname = Convert.ToString(obj["Fname"]);
                EmpReq.Lname = Convert.ToString(obj["Lname"]);
                EmpReq.Email = Convert.ToString(obj["Email"]);
                EmpReq.Department = Convert.ToInt32(obj["Department"]);
                EmpReq.ManagerID = Convert.ToInt32(obj["ManagerID"]);
                EmpReq.method = Convert.ToString(obj["method"]);
                EmpRes = objcommon.Retrieve_EmployeeData(EmpReq);
            }
            //if (EmpReq.EmpID == 0)
            //{
            //    //EmpRes = objcommon.Retrieve_EmployeeData(EmpReq);
            //}
            return EmpRes;
        }

        [HttpPost("Retrieve_Department")]
        public DepartmentRes Retrieve_Department(Master _RequestData)
        {
            DepartmentReq DeptReq = new DepartmentReq();
            DepartmentRes DeptRes = new DepartmentRes();
            Common objcommon = new Common(Configuration);

            JObject obj = objcommon.Jobjdata(_RequestData.requestText);
            //JObject obj = (JObject)_RequestData.requestText;
            if (obj.Count != 0)
            {
                DeptReq.DepartmentID = Convert.ToInt32(obj["DepartmentID"]);
                DeptReq.DepartmentName = Convert.ToString(obj["DepartmentName"]);
                DeptReq.method = Convert.ToString(obj["method"]);
                DeptRes = objcommon.Retrieve_DepartmentData(DeptReq);
            }

            //if (EmpReq.EmpID == 0)
            //{
            //    //EmpRes = objcommon.Retrieve_EmployeeData(EmpReq);
            //}
            return DeptRes;
        }


        [HttpPost("Insert_Employee")]
        public EmployeeRes Insert_Employee(Master _RequestData)
        {
            EmployeeReq EmpReq = new EmployeeReq();
            EmployeeRes EmpRes = new EmployeeRes();
            Common objcommon = new Common(Configuration);

            //JObject obj = (JObject)_RequestData.requestText;
            JObject obj = objcommon.Jobjdata(_RequestData.requestText);
            if (obj.Count != 0)
            {
                EmpReq.EmpID = Convert.ToInt32(obj["EmpID"]);
                EmpReq.Fname = Convert.ToString(obj["Fname"]);
                EmpReq.Lname = Convert.ToString(obj["Lname"]);
                EmpReq.Email = Convert.ToString(obj["Email"]);
                EmpReq.Department = Convert.ToInt32(obj["Department"]);
                EmpReq.ManagerID = Convert.ToInt32(obj["ManagerID"]);
                EmpReq.method = Convert.ToString(obj["method"]);
            }

            if(EmpReq.EmpID == 0)
            {
                EmpRes = objcommon.Insert_EmployeeData(EmpReq);

            }
            //string res = EmpRes.ToString();
            return EmpRes;
                
        }

        [HttpPost("Insert_Department")]
        public DepartmentRes Insert_Department(Master _RequestData)
        {
            DepartmentReq DeptReq = new DepartmentReq();
            DepartmentRes deptres = new DepartmentRes();
            Common objcommon = new Common(Configuration);

            //JObject obj = (JObject)_RequestData.requestText;
            JObject obj = objcommon.Jobjdata(_RequestData.requestText);
            if (obj.Count != 0)
            {
                DeptReq.DepartmentID = Convert.ToInt32(obj["DepartmentID"]);
                DeptReq.DepartmentName = Convert.ToString(obj["DepartmentName"]);
                DeptReq.method = Convert.ToString(obj["method"]);
            }

            if (DeptReq.DepartmentID == 0)
            {
                deptres = objcommon.Insert_DepartmentData(DeptReq);

            }
            //string res = EmpRes.ToString();
            return deptres;

        }


        [HttpPost("Update_Employee")]
        public EmployeeRes Update_Employee(Master _RequestData)
        {
            EmployeeReq EmpReq = new EmployeeReq();
            EmployeeRes EmpRes = new EmployeeRes();
            Common objcommon = new Common(Configuration);

            try
            {
                JObject obj = objcommon.Jobjdata(_RequestData.requestText);
                //JObject obj = (JObject)_RequestData.requestText;
                if (obj.Count != 0)
                {
                    EmpReq.EmpID = Convert.ToInt32(obj["EmpID"]);
                    EmpReq.Fname = Convert.ToString(obj["Fname"]);
                    EmpReq.Lname = Convert.ToString(obj["Lname"]);
                    EmpReq.Email = Convert.ToString(obj["Email"]);
                    EmpReq.Department = Convert.ToInt32(obj["Department"]);
                    EmpReq.ManagerID = Convert.ToInt32(obj["ManagerID"]);
                    EmpReq.method = Convert.ToString(obj["method"]);
                }

                if (EmpReq.EmpID != 0)
                {
                    EmpRes = objcommon.Update_EmployeeData(EmpReq);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return EmpRes;
        }

        [HttpPost("Delete_Employee")]
        public string Delete_Employee(Master _RequestData)
        {
            EmployeeReq EmpReq = new EmployeeReq();
            EmployeeRes EmpRes = new EmployeeRes();
            Common objcommon = new Common(Configuration);
            try
            {
                JObject obj = objcommon.Jobjdata(_RequestData.requestText);
                //JObject obj = (JObject)_RequestData.requestText;
                if (obj.Count != 0)
                {
                    EmpReq.EmpID = Convert.ToInt32(obj["EmpID"]);
                    EmpReq.Fname = Convert.ToString(obj["Fname"]);
                    EmpReq.Lname = Convert.ToString(obj["Lname"]);
                    EmpReq.Email = Convert.ToString(obj["Email"]);
                    EmpReq.Department = Convert.ToInt32(obj["Department"]);
                    EmpReq.ManagerID = Convert.ToInt32(obj["ManagerID"]);
                    EmpReq.method = Convert.ToString(obj["method"]);
                }

                if (EmpReq.EmpID != 0)
                {
                    EmpRes = objcommon.Delete_EmployeeData(EmpReq);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return EmpRes.ToString();
        }

        [HttpPost("Update_Department")]
        public DepartmentRes Update_Department(Master _RequestData)
        {
            DepartmentReq deptreq = new DepartmentReq();
            DepartmentRes deptres = new DepartmentRes();
            Common objcommon = new Common(Configuration);

            try
            {
                JObject obj = objcommon.Jobjdata(_RequestData.requestText);
                //JObject obj = (JObject)_RequestData.requestText;
                if (obj.Count != 0)
                {
                    deptreq.DepartmentID = Convert.ToInt32(obj["DepartmentID"]);
                    deptreq.DepartmentName = Convert.ToString(obj["DepartmentName"]);
                    deptreq.method = Convert.ToString(obj["method"]);
                }

                if (deptreq.DepartmentID != 0)
                {
                    deptres = objcommon.Update_DepartmentData(deptreq);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptres;
        }

        [HttpPost("Delete_Department")]
        public DepartmentRes Delete_Department(Master _RequestData)
        {
            DepartmentReq deptreq = new DepartmentReq();
            DepartmentRes deptres = new DepartmentRes();
            Common objcommon = new Common(Configuration);
            try
            {
                JObject obj = objcommon.Jobjdata(_RequestData.requestText);
                //JObject obj = (JObject)_RequestData.requestText;
                if (obj.Count != 0)
                {
                    deptreq.DepartmentID = Convert.ToInt32(obj["DepartmentID"]);
                    deptreq.DepartmentName = Convert.ToString(obj["DepartmentName"]);
                    deptreq.method = Convert.ToString(obj["method"]);
                }

                if (deptreq.DepartmentID != 0)
                {
                    deptres = objcommon.Delete_DepartmentData(deptreq);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptres;
        }



    }
}
