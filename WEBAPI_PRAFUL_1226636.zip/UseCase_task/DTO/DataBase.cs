﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace UseCase_task.DTO
{  
    public class DataBase
    {
        private IConfiguration Configuration { get; }

        public DataBase(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public DataSet GetDataFromDB(object[] objparam, string sproc)
        {
            string constr = Configuration["ConnectionStrings:conn"];
            SqlConnection scon = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            try
            {
                if(!string.IsNullOrEmpty(sproc))
                {
                    if(objparam != null)
                    {
                        cmd.Connection = scon;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = sproc;
                        if (scon.State == ConnectionState.Closed)
                        {
                            scon.Open();
                        }
                        SqlCommandBuilder.DeriveParameters(cmd);
                        int i = 1;
                        foreach(object param in objparam)
                        {
                            cmd.Parameters[i].Value = param;
                            i++;

                        }
                        da.Fill(ds);
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return ds;
        }
        
    }
}
