﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UseCase_task.DTO
{
    public class Master
    {
        public string requestText { get; set; }
    }

    public class DepartmentReq
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }

        public string method { get; set; }

    }

    public class EmployeeReq
    {
        public int EmpID { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Email { get; set; }
        public int Department { get; set; }
        public int ManagerID { get; set; }
        public string method { get; set; }
    }

    public class DepartmentRes
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }

        public List<DepartmentReq> DepartmentList { get; set; }
        public DepartmentReq Data { get; set; }

    }

    public class EmployeeRes
    {
        public int EmpID { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Email { get; set; }
        public int Department { get; set; }
        public int ManagerID { get; set; }
        public List<EmployeeReq> EmployeeList { get; set; }

        public EmployeeReq Data { get; set; }
    }




}
