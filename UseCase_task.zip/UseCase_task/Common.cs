﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UseCase_task.DTO;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;


namespace UseCase_task
{
    public class Common
    {
        private IConfiguration Configuration { get; }

        public Common(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public EmployeeRes Retrieve_EmployeeData(EmployeeReq emp)
        {
            DataSet ds = new DataSet();
            EmployeeRes empres = new EmployeeRes();
            List<EmployeeReq> EmployeeDetails = new List<EmployeeReq>();
            try
            {
                DataBase db = new DataBase(Configuration);
                object[] obj = new object[7];
                obj[0] = emp.EmpID;
                obj[1] = emp.Fname;
                obj[2] = emp.Lname;
                obj[3] = emp.Email;
                obj[4] = emp.Department;
                obj[5] = emp.ManagerID;
                obj[6] = emp.method;
                ds = db.GetDataFromDB(obj, "SP_CRUD_EmployeeDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {

                        EmployeeDetails.Add(new EmployeeReq
                        {
                            EmpID = Convert.ToInt32(row[0]),
                            Fname = Convert.ToString(row[1]),
                            Lname = Convert.ToString(row[2]),
                            Email = Convert.ToString(row[3]),
                            Department = Convert.ToInt32(row[4]),
                            ManagerID = Convert.ToInt32(row[5]),
                    });
                        empres.EmployeeList = EmployeeDetails;
                        //empres.Data = EmployeeDetails;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empres;
        }

        public DepartmentRes Retrieve_DepartmentData(DepartmentReq dept)
        {
            DataSet ds = new DataSet();
            DepartmentRes deptres = new DepartmentRes();
            List<DepartmentReq> DepartmentDetails = new List<DepartmentReq>();
            try
            {
                DataBase db = new DataBase(Configuration);
                object[] obj = new object[3];
                obj[0] = dept.DepartmentID;
                obj[1] = dept.DepartmentName;
                obj[2] = dept.method;
                ds = db.GetDataFromDB(obj, "SP_CRUD_DepartmentDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {

                        DepartmentDetails.Add(new DepartmentReq
                        {
                            DepartmentID = Convert.ToInt32(row[0]),
                            DepartmentName = Convert.ToString(row[1]),
                        });
                        deptres.DepartmentList = DepartmentDetails;
                        //empres.Data = EmployeeDetails;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptres;
        }

        public EmployeeRes Insert_EmployeeData(EmployeeReq emp)
        {
            DataSet ds = new DataSet();
            EmployeeRes empres = new EmployeeRes();
            try
            {
                DataBase db = new DataBase(Configuration);
                object[] obj = new object[7];
                obj[0] = emp.EmpID;
                obj[1] = emp.Fname;
                obj[2] = emp.Lname;
                obj[3] = emp.Email;
                obj[4] = emp.Department;
                obj[5] = emp.ManagerID;
                obj[6] = emp.method; 
                

                ds = db.GetDataFromDB(obj, "SP_CRUD_EmployeeDetails");
                if(ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    emp.EmpID = Convert.ToInt32(ds.Tables[0].Rows[0]["EmpID"]);
                    emp.Fname = ds.Tables[0].Rows[0]["Fname"].ToString();
                    emp.Lname = ds.Tables[0].Rows[0]["Lname"].ToString();
                    emp.Email = ds.Tables[0].Rows[0]["Email"].ToString();
                    emp.Department = Convert.ToInt32(ds.Tables[0].Rows[0]["Department"]);
                    emp.ManagerID = Convert.ToInt32(ds.Tables[0].Rows[0]["ManagerID"]);
                    //emp.method = Convert.ToString(ds.Tables[0].Rows[0]["method"]);
                    empres.Data = emp;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return empres;

        }


        public DepartmentRes Insert_DepartmentData(DepartmentReq dept)
        {
            DataSet ds = new DataSet();
            DepartmentRes deptres = new DepartmentRes();
            try
            {
                DataBase db = new DataBase(Configuration);
                object[] obj = new object[3];
                obj[0] = dept.DepartmentID;
                obj[1] = dept.DepartmentName;
                obj[2] = dept.method;


                ds = db.GetDataFromDB(obj, "SP_CRUD_DepartmentDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    dept.DepartmentID = Convert.ToInt32(ds.Tables[0].Rows[0]["DepartmentID"]);
                    dept.DepartmentName = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                    deptres.Data = dept;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptres;

        }

        public EmployeeRes Update_EmployeeData(EmployeeReq emp)
        {

            DataSet ds = new DataSet();
            EmployeeRes empres = new EmployeeRes();
            try
            {

                DataBase db = new DataBase(Configuration);
                object[] obj = new object[7];
                obj[0] = emp.EmpID;
                obj[1] = emp.Fname;
                obj[2] = emp.Lname;
                obj[3] = emp.Email;
                obj[4] = emp.Department;
                obj[5] = emp.ManagerID;
                obj[6] = emp.method;
                ds = db.GetDataFromDB(obj, "SP_CRUD_EmployeeDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    emp.EmpID = Convert.ToInt32(ds.Tables[0].Rows[0]["EmpID"]);
                    emp.Fname = Convert.ToString(ds.Tables[0].Rows[0]["Fname"]);
                    emp.Lname = Convert.ToString(ds.Tables[0].Rows[0]["Lname"]);
                    emp.Email = Convert.ToString(ds.Tables[0].Rows[0]["Email"]);
                    emp.Department = Convert.ToInt32(ds.Tables[0].Rows[0]["Department"]);
                    emp.ManagerID = Convert.ToInt32(ds.Tables[0].Rows[0]["ManagerID"]);
                    empres.Data = emp;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empres;

        }

        public EmployeeRes Delete_EmployeeData(EmployeeReq emp)
        {

            DataSet ds = new DataSet();
            EmployeeRes empres = new EmployeeRes();
            try
            {

                DataBase db = new DataBase(Configuration);
                object[] obj = new object[7];
                obj[0] = emp.EmpID;
                obj[1] = emp.Fname;
                obj[2] = emp.Lname;
                obj[3] = emp.Email;
                obj[4] = emp.Department;
                obj[5] = emp.ManagerID;
                obj[6] = emp.method;
                ds = db.GetDataFromDB(obj, "SP_CRUD_EmployeeDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    emp.EmpID = Convert.ToInt32(ds.Tables[0].Rows[0]["EmpID"]);
                    emp.Fname = Convert.ToString(ds.Tables[0].Rows[0]["Fname"]);
                    emp.Lname = Convert.ToString(ds.Tables[0].Rows[0]["Lname"]);
                    emp.Email = Convert.ToString(ds.Tables[0].Rows[0]["Email"]);
                    emp.Department = Convert.ToInt32(ds.Tables[0].Rows[0]["Department"]);
                    emp.ManagerID = Convert.ToInt32(ds.Tables[0].Rows[0]["ManagerID"]);
                    empres.Data = emp;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empres;

        }


        public DepartmentRes Update_DepartmentData(DepartmentReq dept)
        {

            DataSet ds = new DataSet();
            DepartmentRes deptres = new DepartmentRes();
            try
            {

                DataBase db = new DataBase(Configuration);
                object[] obj = new object[3];
                obj[0] = dept.DepartmentID;
                obj[1] = dept.DepartmentName;
                obj[2] = dept.method;
                ds = db.GetDataFromDB(obj, "SP_CRUD_DepartmentDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    dept.DepartmentID = Convert.ToInt32(ds.Tables[0].Rows[0]["DepartmentID"]);
                    dept.DepartmentName = Convert.ToString(ds.Tables[0].Rows[0]["DepartmentName"]);
                    deptres.Data = dept;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptres;

        }

        public DepartmentRes Delete_DepartmentData(DepartmentReq dept)
        {

            DataSet ds = new DataSet();
            DepartmentRes deptres = new DepartmentRes();
            try
            {
                DataBase db = new DataBase(Configuration);
                object[] obj = new object[3];
                obj[0] = dept.DepartmentID;
                obj[1] = dept.DepartmentName;
                obj[2] = dept.method;
                ds = db.GetDataFromDB(obj, "SP_CRUD_DepartmentDetails");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    dept.DepartmentID = Convert.ToInt32(ds.Tables[0].Rows[0]["DepartmentID"]);
                    dept.DepartmentName = Convert.ToString(ds.Tables[0].Rows[0]["DepartmentName"]);
                    deptres.Data = dept;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptres;

        }

        public JObject Jobjdata(string requestText)
        {
            JObject obj = new JObject();
            obj = JObject.Parse(requestText);
            return obj;
        }


    }
}
